package lessonMapper.query.rankboost;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;
import util.SortedScoreRankList;

public class LuceneRanker extends Ranker {

	

	@Override
	SortedScoreRankList<LOM> getSortedScoreRankList(LOMRanking aLOMRanking) {
		return aLOMRanking.getLuceneResults();
	}
	
	@Override
	public String toString() {
		return "Lucene";
	}
	
	public int compareTo(Ranker aRanker) {
		if (aRanker.getClass() != getClass()) return getClass().getName().compareTo(aRanker.getClass().getName());
		return 0;
	}
	
}
