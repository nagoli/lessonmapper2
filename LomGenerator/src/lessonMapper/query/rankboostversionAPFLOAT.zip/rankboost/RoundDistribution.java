package lessonMapper.query.rankboost;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;
import org.apfloat.ApfloatMath;

import util.Couple;

public class RoundDistribution extends BipartiteDistribution {

	BipartiteDistribution itsPreviousDistribution;
	Hypothesis itsHypothesis;
	Apfloat itsAlpha;
	

	public RoundDistribution(BipartiteDistribution aPreviousDistribution, Hypothesis aHypothesis, Apfloat aAlpha) {
		super();
		itsPreviousDistribution = aPreviousDistribution;
		itsHypothesis = aHypothesis;
		itsAlpha = aAlpha;
		initVFunction();
	}

	/**
	 * init vfunction and init z
	 *
	 */
	public void initVFunction(){
		Map<Couple<LOMRanking,LOM>, Apfloat> theTempV0= new HashMap<Couple<LOMRanking,LOM>, Apfloat>(), theTempV1 = new HashMap<Couple<LOMRanking,LOM>, Apfloat>();
		Apfloat theZ0 = ZERO, theZ1 = ZERO; 
		for (Couple<LOMRanking,LOM> theLOM : getLOMList()) {
			Apfloat theV; 
			if (isExpected(theLOM)){
				if (itsHypothesis.getValueFor(theLOM)==1)
					theV= itsPreviousDistribution.getV(theLOM).multiply(ApfloatMath.exp(itsAlpha.negate()).precision(ITSPrecision));
				else theV= itsPreviousDistribution.getV(theLOM);
				theZ1 = theZ1.add(theV);
				theTempV1.put(theLOM, theV);
			}
			else {
				if (itsHypothesis.getValueFor(theLOM)==1)
					theV =itsPreviousDistribution.getV(theLOM).multiply(ApfloatMath.exp(itsAlpha).precision(ITSPrecision));
				else theV= itsPreviousDistribution.getV(theLOM);
				theZ0 = theZ0.add(theV);
				theTempV0.put(theLOM, theV);
			}
		}
		// normalize V
		for (Couple<LOMRanking,LOM> theLOM : theTempV0.keySet()) 
			itsVFunction.put(theLOM, theTempV0.get(theLOM).divide(theZ0));
		for (Couple<LOMRanking,LOM> theLOM : theTempV1.keySet()) 
			itsVFunction.put(theLOM, theTempV1.get(theLOM).divide(theZ1));
	}

	
	
	@Override
	public boolean isExpected(Couple<LOMRanking,LOM> aLOM) {
		return itsPreviousDistribution.isExpected(aLOM);
	}
	
	@Override
	public List<Couple<LOMRanking,LOM>> getLOMList() {
		return itsPreviousDistribution.getLOMList();
	}
	
	@Override
	public List<Couple<LOMRanking,LOM>> getExpectedLOMList() {
		return itsPreviousDistribution.getExpectedLOMList();
	}
	
	
}
