package lessonMapper.query.rankboost;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;
import org.apfloat.ApfloatMath;

import util.Couple;

public class BipartiteScoreAndRankBoost extends BipartiteRankBoostAbstract {


	
	static protected List<Integer> itsRankThresholdList;
	static {
		 itsRankThresholdList = new ArrayList<Integer>();
		for (int i =-1 ; i>=-1*LOMRanking.ITSEntireDBLOMs.size()-1; i--)
			itsRankThresholdList.add(i);
	}
	
	
	
	static protected List<Double> itsScoreThresholdList;
	static {
		itsScoreThresholdList = new ArrayList<Double>();
		for (double i =1 ; i>=0; i-=0.01)
			itsScoreThresholdList.add(i);
	}
	
	
	public BipartiteScoreAndRankBoost(int aRoundNb, List<LOMRanking> aQueryList,
			List<Couple<LOMRanking, LOM>> aWholeLOMList,
			List<Couple<LOMRanking, LOM>> aExpectedLOMList) {
		super(aRoundNb,aQueryList,aWholeLOMList,aExpectedLOMList);
		
	}

	public BipartiteScoreAndRankBoost(
			Map<Hypothesis, Apfloat> aHypothesisAndAlphaList) {
		super(aHypothesisAndAlphaList);
	}
	/**
	 * 
	 * implementation of weak learn with q=0 (default value)
	 * return a weak hypotesis (fi, teta) and alpha (based on the third proposition:  see getAlpha) 
	 * (algo fig 4.2)
	 * @param aLOMList
	 * @param aDistribution
	 * @param aRankerList
	 * @return
	 */
	public Couple<Hypothesis, Apfloat> weakLearn(List<Couple<LOMRanking, LOM>> aLOMList, BipartiteDistribution aDistribution, List<Ranker> aRankerList) {
		Hypothesis theWeakHypothesis = null;
		//init the Pi(x) with pi(x) = d(x)s(x) since we are in the bipartite case
		Map<Couple<LOMRanking, LOM>, Apfloat> thePiMap = new HashMap<Couple<LOMRanking, LOM>, Apfloat>();
		for (Couple<LOMRanking, LOM> theLOM : aLOMList) 
			thePiMap.put(theLOM, aDistribution.getD(theLOM).multiply(aDistribution.getS(theLOM)));
	
		Apfloat r = ZERO;
		//look for the weakHypothesis		
		for (Ranker theRanker : aRankerList) {
			Apfloat L = ZERO;
			for (int j = 1; j < itsScoreThresholdList.size(); j++) {
				Apfloat theSupThresholdSum = ZERO;
					for (LOMRanking theRanking : itsQueryList){
						Collection<LOM> theLOMs = theRanker.getLOMForScore(
								theRanking, itsScoreThresholdList.get(j-1),itsScoreThresholdList.get(j) );
						if (theLOMs!=null) 
							for (LOM theLOM : theLOMs) 
								theSupThresholdSum = theSupThresholdSum.add(thePiMap.get(new Couple<LOMRanking, LOM>(theRanking, theLOM)));
					}
				L = L.add(theSupThresholdSum);
				if (ApfloatMath.abs(L).compareTo(ApfloatMath.abs(r))>0) {
					Hypothesis theHypothesis = new ScoreHypothesis(theRanker,
							itsScoreThresholdList.get(j));
					// cummulative weaklearner checking
					if (getAlpha(L).add(getAlpha(theHypothesis)).signum()>=0){
						r = L;
						theWeakHypothesis = theHypothesis;
					}
				}
			}
		}
		//look for weakHypothesis in rank
		for (Ranker theRanker : aRankerList) {
			Apfloat L = ZERO;
			for (int j = 1; j < itsRankThresholdList.size(); j++) {
				Apfloat theSupThresholdSum = ZERO;
				for (int rank = itsRankThresholdList.get(j - 1); rank > itsRankThresholdList
						.get(j); rank--)
					for (LOMRanking theRanking : itsQueryList){
						List<LOM> theLOMList = theRanker.getLOM(theRanking, rank);
						if (theLOMList!= null)
							for (LOM theLOM: theLOMList)
								if (theLOM!=null) 
									theSupThresholdSum= theSupThresholdSum.add(thePiMap.get(new Couple<LOMRanking, LOM>(theRanking, theLOM)));
					}
				L = L.add(theSupThresholdSum);
				if (ApfloatMath.abs(L).compareTo(ApfloatMath.abs(r))>0) {
					Hypothesis theHypothesis = new RankHypothesis(theRanker,itsRankThresholdList.get(j));
					// cummulative weaklearner checking
					if (getAlpha(L).add(getAlpha(theHypothesis)).signum()>=0){
						r = L;
						theWeakHypothesis = theHypothesis;
					}
				}
			}
		}
		return new Couple<Hypothesis, Apfloat>(theWeakHypothesis, getAlpha(r));
	}
	
}
