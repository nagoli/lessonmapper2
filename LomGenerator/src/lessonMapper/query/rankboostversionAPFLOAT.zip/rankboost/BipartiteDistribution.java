package lessonMapper.query.rankboost;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;

import util.Couple;

public abstract class BipartiteDistribution {

	static public long ITSPrecision = BipartiteRankBoostAbstract.ITSPrecision;
	static public Apfloat ZERO = BipartiteRankBoostAbstract.ZERO;
	static public Apfloat ONE = BipartiteRankBoostAbstract.ONE;
	static public Apfloat TWO = BipartiteRankBoostAbstract.TWO;
	static public Apfloat MINUSONE = BipartiteRankBoostAbstract.MINUSONE;
	
	
	boolean isSumVExpectedInit = false;

	Apfloat itsSumVExpected;

	boolean isSumVNotExpectedInit = false;

	Apfloat itsSumVNotExpected;

	Map<Couple<LOMRanking, LOM>, Apfloat> itsVFunction = new HashMap<Couple<LOMRanking, LOM>, Apfloat>();

	/**
	 * definition 4.7 :  D(x0,x1) = v(x0)*v(x1)
	 */
	public Apfloat getD(Couple<LOMRanking, LOM> aX0, Couple<LOMRanking, LOM> aX1) {
		if (isExpected(aX1))
			return itsVFunction.get(aX0).multiply(itsVFunction.get(aX1));
		return ZERO;
	}

	/**
	 * definition 4.7 :  D(x) = v(x)*sum (v(x1)) for x in X0 
	 * 						    v(x)*sum(v(x0))  for x in x1
	 */
	public Apfloat getD(Couple<LOMRanking, LOM> aX) {
		if (isExpected(aX))
			return getV(aX).multiply(getSumVNotExpected());
		else return getV(aX).multiply(getSumVExpected());
	}

	public Apfloat getS(Couple<LOMRanking, LOM> aX) {
		if (isExpected(aX))
			return ONE;
		return MINUSONE;
	}

	public Apfloat getV(Couple<LOMRanking, LOM> theCouple) {
		return itsVFunction.get(theCouple);
	}

	public Apfloat getSumVExpected() {
		if (!isSumVExpectedInit||itsSumVExpected==null) {
			itsSumVExpected = ZERO;
			for (Couple<LOMRanking, LOM> theCouple : getExpectedLOMList())
				itsSumVExpected = itsSumVExpected.add(getV(theCouple));
			isSumVExpectedInit=true;
		}
		return itsSumVExpected;
	}

	public Apfloat getSumVNotExpected() {
		if (!isSumVNotExpectedInit|| itsSumVNotExpected == null) {
			itsSumVNotExpected = ZERO;
			for (Couple<LOMRanking, LOM> theCouple : getLOMList()){
				if (!isExpected(theCouple))
					itsSumVNotExpected = itsSumVNotExpected.add(getV(theCouple));
			}
			isSumVNotExpectedInit =true;
		}
		return itsSumVNotExpected;
	}

	public abstract boolean isExpected(Couple<LOMRanking, LOM> aLOM);

	public abstract List<Couple<LOMRanking, LOM>> getLOMList();

	public abstract List<Couple<LOMRanking, LOM>> getExpectedLOMList();

}
