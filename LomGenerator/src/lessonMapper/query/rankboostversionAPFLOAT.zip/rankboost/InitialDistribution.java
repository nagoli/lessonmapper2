package lessonMapper.query.rankboost;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;

import util.Couple;
/**
 * initial distribution is based on the bipartite rankboost definition:
 * we have to disjoint subset X0 and X1 respectively the not expected lom set and the expected lom set
 * this distribution will rank all X1 over X0 and say nothing about the others
 * 
 * @author omotelet
 *
 */
public class InitialDistribution extends BipartiteDistribution {

	List<Couple<LOMRanking,LOM>> itsExpectedLOMList, itsWholeLOMList;
	Map<Couple<LOMRanking,LOM>, Boolean> isExpectedMap = new HashMap<Couple<LOMRanking,LOM>, Boolean>();
  
	public InitialDistribution(List<Couple<LOMRanking,LOM>> aExpectedLOMList, List<Couple<LOMRanking,LOM>> aWholeLOMList) {
		super();
		itsExpectedLOMList = aExpectedLOMList;
		itsWholeLOMList = aWholeLOMList;
		for (Couple<LOMRanking,LOM> theLom : itsExpectedLOMList) {
			itsVFunction.put(theLom, ONE.divide(new Apfloat(itsExpectedLOMList.size()).precision(ITSPrecision)));
			isExpectedMap.put(theLom, true);
		}
		for (Couple<LOMRanking,LOM> theLom : itsWholeLOMList) 
			if (!itsVFunction.containsKey(theLom)){
				itsVFunction.put(theLom, ONE.divide(new Apfloat(itsWholeLOMList.size()-itsExpectedLOMList.size()).precision(ITSPrecision)));
				isExpectedMap.put(theLom, false);
			}
	}

	
	@Override
	public boolean isExpected(Couple<LOMRanking,LOM> aLOM) {
		return isExpectedMap.get(aLOM);
	}

	@Override
	public List<Couple<LOMRanking,LOM>> getLOMList() {
		return itsWholeLOMList;
	}
	
	@Override
	public List<Couple<LOMRanking,LOM>> getExpectedLOMList() {
		return itsExpectedLOMList;
	}
	
	
}
