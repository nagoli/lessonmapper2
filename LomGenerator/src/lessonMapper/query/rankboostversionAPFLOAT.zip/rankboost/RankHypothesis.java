package lessonMapper.query.rankboost;



import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;
import util.Couple;



public class RankHypothesis extends Hypothesis {

	public RankHypothesis(Ranker aRanker, double aTeta) {
		super(aRanker, aTeta);
	}

	
	/**
	 * return 1 if rank > teta else 0
	 * @param theCouple
	 * @return
	 */
	public int getValueFor(Couple<LOMRanking,LOM> theCouple){
		if (itsRanker.getRank(theCouple.getLeftElement(),theCouple.getRightElement())> getDoubleTeta())
			return 1;
		return 0;
	}
	
	
	
}
