package lessonMapper.query.rankboost;

import lessonMapper.lom.LOM;
import lessonMapper.lom.LOMAttribute;
import lessonMapper.query.LOMRanking;
import util.SortedScoreRankList;

public class ResRanker extends Ranker {

	 LOMAttribute itsAttribute;
	
	
	public ResRanker(LOMAttribute aAttribute) {
		super();
		itsAttribute = aAttribute;
	}

	@Override
	SortedScoreRankList<LOM> getSortedScoreRankList(LOMRanking aLOMRanking) {
		return aLOMRanking.getRestrictionResults(itsAttribute);
	}
	
	
	@Override
	public String toString() {
		return "Restriction-"+ itsAttribute.getName();
	}
	
	public int compareTo(Ranker aRanker) {
		if (aRanker.getClass() != getClass()) return getClass().getName().compareTo(aRanker.getClass().getName());
		ResRanker theRanker = (ResRanker)aRanker;
		if (theRanker.itsAttribute != itsAttribute) return itsAttribute.getName().compareTo(theRanker.itsAttribute.getName());
		return 0;
	}
}
