package lessonMapper.query.rankboost;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lessonMapper.lom.LOM;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;
import org.apfloat.ApfloatMath;

import util.Couple;

public class BipartiteScoreBoost extends BipartiteRankBoostAbstract {


	static protected List<Double> itsThresholdList;
	static {
		itsThresholdList = new ArrayList<Double>();
		for (double i =1 ; i>=-0.01; i-=0.01)
			itsThresholdList.add(i);
	}
	
	
	public BipartiteScoreBoost(int aRoundNb, List<LOMRanking> aQueryList,
			List<Couple<LOMRanking, LOM>> aWholeLOMList,
			List<Couple<LOMRanking, LOM>> aExpectedLOMList) {
		super(aRoundNb,aQueryList,aWholeLOMList,aExpectedLOMList);
		
	}

	public BipartiteScoreBoost(
			Map<Hypothesis, Apfloat> aHypothesisAndAlphaList) {
		super(aHypothesisAndAlphaList);
	}
	/**
	 * 
	 * implementation of weak learn with q=0 (default value)
	 * return a weak hypotesis (fi, teta) and alpha (based on the third proposition:  see getAlpha) 
	 * (algo fig 4.2)
	 * @param aLOMList
	 * @param aDistribution
	 * @param aRankerList
	 * @return
	 */
	public Couple<Hypothesis, Apfloat> weakLearn(List<Couple<LOMRanking, LOM>> aLOMList, BipartiteDistribution aDistribution, List<Ranker> aRankerList) {
		Hypothesis theWeakHypothesis = null;
		//init the Pi(x) with pi(x) = d(x)s(x) since we are in the bipartite case
		Map<Couple<LOMRanking, LOM>, Apfloat> thePiMap = new HashMap<Couple<LOMRanking, LOM>, Apfloat>();
		for (Couple<LOMRanking, LOM> theLOM : aLOMList) 
			thePiMap.put(theLOM, aDistribution.getD(theLOM).multiply(aDistribution.getS(theLOM)));
	
		Apfloat r = ZERO;
		//look for the weakHypothesis		
		for (Ranker theRanker : aRankerList) {
			Apfloat L = ZERO;
			for (int j = 1; j < itsThresholdList.size(); j++) {
				Apfloat theSupThresholdSum = ZERO;
					for (LOMRanking theRanking : itsQueryList){
						Collection<LOM> theLOMs = theRanker.getLOMForScore(
								theRanking, itsThresholdList.get(j-1),itsThresholdList.get(j) );
						if (theLOMs!=null) 
							for (LOM theLOM : theLOMs) 
								theSupThresholdSum = theSupThresholdSum.add(thePiMap.get(new Couple<LOMRanking, LOM>(theRanking, theLOM)));
					}
				L = L.add(theSupThresholdSum);
				if (ApfloatMath.abs(L).compareTo(ApfloatMath.abs(r))>0) {
					Hypothesis theHypothesis = new ScoreHypothesis(theRanker,
							itsThresholdList.get(j));
					// cummulative weaklearner checking
					if (getAlpha(L).add(getAlpha(theHypothesis)).signum()>=0){
						r = L;
						theWeakHypothesis = theHypothesis;
					}
				}
			}
		}
		return new Couple<Hypothesis, Apfloat>(theWeakHypothesis, getAlpha(r));
	}
	
}
