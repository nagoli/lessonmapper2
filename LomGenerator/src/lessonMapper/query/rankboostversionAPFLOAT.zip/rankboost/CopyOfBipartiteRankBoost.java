package lessonMapper.query.rankboost;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import util.Couple;

import lessonMapper.lom.LOM;

public class CopyOfBipartiteRankBoost {

	int itsRoundNb;
	List<Ranker> itsRankerList;
	List<Couple<Hypothesis,Double>> itsHypothesisAndAlphaList;
	List<LOM> itsWholeLOMList, itsExpectedLOMList;
	
	public CopyOfBipartiteRankBoost(int aRoundNb, List<Ranker> aRankerList, List<LOM> aWholeLOMList, List<LOM> aExpectedLOMList) {
		itsRoundNb = aRoundNb;
		itsRankerList = aRankerList;
		itsWholeLOMList = aWholeLOMList;
		itsExpectedLOMList = aExpectedLOMList;
		itsHypothesisAndAlphaList = new ArrayList<Couple<Hypothesis,Double>>();
	}
	
	/**
	 * 
	 *
	 */
	public void buildHypothesis(){
		BipartiteDistribution theDistribution = new InitialDistribution(itsExpectedLOMList,itsWholeLOMList);
		for (int i = 0; i<itsRoundNb;i++ ){
			Couple<Hypothesis,Double> theCouple =  weakLearn(itsWholeLOMList, theDistribution, itsRankerList);
			theDistribution = new RoundDistribution(theDistribution,theCouple.getLeftElement(),theCouple.getRightElement());
			itsHypothesisAndAlphaList.add(theCouple);
		}
	}
	
	public double getHypothesisFor(LOM aLOM){
		
	}
	

	/**
	 * return a weak hypotesis (fi, teta, q_def) and alpha (based on the third proposition:  see getAlpha) 
	 * (algo fig 4.2)
	 * @param aLOMList
	 * @param aDistribution
	 * @param aRankerList
	 * @return
	 */
	public  Couple<Hypothesis, Double> weakLearn(List<LOM> aLOMList, BipartiteDistribution aDistribution, List<Ranker> aRankerList){
		Hypothesis theWeakHypothesis = null;
		//init the Pi(x)
		Map<LOM, Double> thePiMap =new HashMap<LOM, Double>();
		for (LOM theLOM : aLOMList) {
			double thePi = 0;
			for (LOM theLOM2 : aLOMList) 
				if (theLOM2!=theLOM)
					thePi += aDistribution.getD(theLOM2,theLOM) - aDistribution.getD(theLOM,theLOM2);
			thePiMap.put(theLOM, thePi);
		}
		
		double r =0;
		//look for the weakHypothesis		
		for (Ranker theRanker : aRankerList) {
			int q=0;
			double L = 0;
			double R = 0;
			for (LOM theLOM : theRanker.getRankedLOMs()) 
				R += thePiMap.get(theLOM);
			List<Integer> theThresholdList = theRanker.getThresholds();
			for (int j=1; j < theThresholdList.size(); j++){
				double theSupThresholdSum = 0;
				for ( int rank = theThresholdList.get(j-1); rank > theThresholdList.get(j); rank--)
					theSupThresholdSum += thePiMap.get(theRanker.getLOM(rank));
				L = L + theSupThresholdSum;
				if (Math.abs(L) > Math.abs(L-R))
					q = 0;
				else q = 1;
				if ( Math.abs(L-q*R)>Math.abs(r)){
					r = L-q*R;
					theWeakHypothesis = new Hypothesis(theRanker,theThresholdList.get(j),q);
				}
			}
		}
		return new Couple<Hypothesis, Double>(theWeakHypothesis, getAlpha(r));
	}
	
	/**
	 * return alpha = 0.5 * ln ((1+r)/(1-r))     (def 4.6)
	 */
	public  double getAlpha(double r){
		return 0.5 * (Math.log(1+r) - Math.log(1-r));
	}
	
	
	
	
	
}
