package lessonMapper.query.rankboost;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import lessonMapper.lom.LOM;
import lessonMapper.lom.LOMAttribute;
import lessonMapper.query.LOMRanking;

import org.apfloat.Apfloat;
import org.apfloat.ApfloatMath;

import util.Couple;

public abstract class BipartiteRankBoostAbstract {

	//static public MathContext ITSPrecision = MathContext.DECIMAL64;
	//static public MathContext ITSLowPrecision = MathContext.DECIMAL32;
	static public long ITSPrecision = 25;
	static public Apfloat ZERO = Apfloat.ZERO.precision(ITSPrecision);
	static public Apfloat ONE = Apfloat.ONE.precision(ITSPrecision);
	static public Apfloat TWO = new Apfloat(2).precision(ITSPrecision);
	static public Apfloat MINUSONE = Apfloat.ONE.negate().precision(ITSPrecision);
	
	public static BipartiteRankBoostAbstract getInstance() throws Exception {
		if (ITSInstance == null)
			throw new Exception("RankBook is not initiated");
		return ITSInstance;
	}

	protected static BipartiteRankBoostAbstract ITSInstance;
	protected int itsRoundNb;
	protected Map<Hypothesis, Apfloat> itsHypothesisAndAlphaList;
	protected List<Couple<LOMRanking, LOM>> itsWholeLOMList;
	protected List<Couple<LOMRanking, LOM>> itsExpectedLOMList;
	
	protected List<LOMRanking> itsQueryList;

	protected List<Ranker> itsRankerList;
	{
		itsRankerList = new ArrayList<Ranker>();
		for (LOMAttribute theAttribute : LOMRanking.ITSAttributes) {
			itsRankerList.add(new SugRanker(theAttribute));
		}
		for (LOMAttribute theAttribute : LOMRanking.ITSAttributes) {
			itsRankerList.add(new ResRanker(theAttribute));
		}
		//itsRankerList.add(new LuceneRanker());
	}
	
	
	public BipartiteRankBoostAbstract(int aRoundNb, List<LOMRanking> aQueryList,
			List<Couple<LOMRanking, LOM>> aWholeLOMList,
			List<Couple<LOMRanking, LOM>> aExpectedLOMList) {
		ITSInstance = this;
		itsRoundNb = aRoundNb;
		itsWholeLOMList = aWholeLOMList;
		itsExpectedLOMList = aExpectedLOMList;
		itsQueryList = aQueryList;
		itsHypothesisAndAlphaList = new TreeMap<Hypothesis, Apfloat>();
		buildHypothesis();
	}

	public BipartiteRankBoostAbstract(
			Map<Hypothesis, Apfloat> aHypothesisAndAlphaList) {
		itsHypothesisAndAlphaList = aHypothesisAndAlphaList;
		ITSInstance = this;
	}
	
	
	public abstract Couple<Hypothesis, Apfloat> weakLearn(List<Couple<LOMRanking, LOM>> aLOMList, BipartiteDistribution aDistribution, List<Ranker> aRankerList) ;
		
	
	/**
	 * 
	 *
	 */
	public void buildHypothesis() {
		BipartiteDistribution theDistribution = new InitialDistribution(
				itsExpectedLOMList, itsWholeLOMList);
		for (int i = 0; i < itsRoundNb; i++) {
			Couple<Hypothesis, Apfloat> theCouple = weakLearn(itsWholeLOMList,
					theDistribution, itsRankerList);
			theDistribution = new RoundDistribution(theDistribution, theCouple
					.getLeftElement(), theCouple.getRightElement());
			Apfloat alpha = getAlpha(theCouple.getLeftElement()); 
			itsHypothesisAndAlphaList.put(theCouple.getLeftElement(),theCouple.getRightElement().add(alpha));
			if (i%5 == 0) System.out.print("."+i);
		}
	}

	public double getHypothesisFor(LOMRanking aRanking, LOM aLOM) {
		Apfloat theSum = ZERO; 
		for (Entry<Hypothesis, Apfloat> theCouple : itsHypothesisAndAlphaList.entrySet()) {
			if (theCouple.getKey().getValueFor(
					new Couple<LOMRanking, LOM>(aRanking, aLOM)) == 1)
			theSum = theSum.add(theCouple.getValue());
		}
		return theSum.doubleValue();
	}

	/**
	 * return alpha = 0.5 * ln ((1+r)/(1-r))     (def 4.6)
	 */
	public Apfloat getAlpha(Apfloat r) {
		return ApfloatMath.log(ONE.add(r).divide(ONE.subtract(r))).divide(TWO);
	}

	/**
	 * return theAlpha for an hypotesis equivalent to the Parameter aHypothesis
	 */
	public Apfloat getAlpha(Hypothesis aHypothesis) {
		if (itsHypothesisAndAlphaList.containsKey(aHypothesis)) return itsHypothesisAndAlphaList.get(aHypothesis);
		return ZERO; 
	}

	/**
	 * return hypothesis map
	 */
	public Map<Hypothesis, Apfloat> getHypothesisMap() {
		return itsHypothesisAndAlphaList;
	}

}